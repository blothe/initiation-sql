# Exercices d'inititation à PHP / MySQL

Faire toutes les requêtes du chapitre "PHP MySQL Database" sur le site du w3schools : https://www.w3schools.com/php/php_mysql_intro.asp

Télécharger data.csv puis écrire les requêtes suivantes :

1) Afficher tous les gens dont le nom est palmer
2) Afficher toutes les femmes
3) Tous les états dont la lettre commence par N
4) Tous les emails qui contiennent google
5) Répartition par Etat et le nombre d’enregistrement par état (croissant)
6) Insérer un utilisateur, lui mettre à jour son adresse mail puis supprimer l’utilisateur
7) Nombre de femme et d’homme
8) Afficher l'âge de chaque personne, puis la moyenne d’âge des femmes et des hommes
